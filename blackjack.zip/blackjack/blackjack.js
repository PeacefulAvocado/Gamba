//a pakli teteje a legelso
var lapok = [[1, 'AH'], [2, '2H'], [3, '3H'], [4, '4H'], [5, '5H'], [6, '6H'], [7, '7H'], [8, '8H'], [9, '9H'], [10, '10H'], [10, 'JH'], [10, 'QH'], [10, 'KH'],
[1, 'AD'], [2, '2D'], [3, '3D'], [4, '4D'], [5, '5D'], [6, '6D'], [7, '7D'], [8, '8D'], [9, '9D'], [10, '10D'], [10, 'JD'], [10, 'QD'], [10, 'KD'],
[1, 'AS'], [2, '2S'], [3, '3S'], [4, '4S'], [5, '5S'], [6, '6S'], [7, '7S'], [8, '8S'], [9, '9S'], [10, '10S'], [10, 'JS'], [10, 'QS'], [10, 'KS'],
[1, 'AC'], [2, '2C'], [3, '3C'], [4, '4C'], [5, '5C'], [6, '6C'], [7, '7C'], [8, '8C'], [9, '9C'], [10, '10C'], [10, 'JC'], [10, 'QC'], [10, 'KC']
];

var szamlalo = 0;
var jatekos = [];
var dealer = [];

function keveres()
{
    for (let i = 0; i < 52; i++) {
        let sv = lapok[i];
        let random = Math.floor(Math.random() * (51));
        lapok[i] = lapok[random];
        lapok[random] = sv;
    }
}

function osztas() 
{
    jatekos.push(lapok[szamlalo]);
    kep(lapok[szamlalo][1], 'jatekos')
    szamlalo++;
    dealer.push(lapok[szamlalo]);
    kep(lapok[szamlalo][1], 'dealer')
    szamlalo++;
    jatekos.push(lapok[szamlalo]);
    kep(lapok[szamlalo][1], 'jatekos')
    szamlalo++;
    dealer.push(lapok[szamlalo]);
    kep(lapok[szamlalo][1], 'dealer')
    szamlalo++;
    var dertek = 0;
    dealer.forEach(item => dertek = dertek + item[0]);
    var jertek = 0;
    jatekos.forEach(item => jertek = jertek + item[0]);
    document.getElementById("dertek").innerHTML = dertek;
    document.getElementById("jertek").innerHTML = jertek;
}

function kep(lap, szereplo)
{
    var szam = lap[0];
    var version = "";

    if (szam == "A") {
        szam = "ace";
    } else if (szam == "J") {
        szam = "jack";
        var version = "2"
    } else if (szam == "K") {
        szam = "king";
        var version = "2"
    }else if (szam == "Q") {
        szam = "queen";
        var version = "2"
    }else if (szam == "1") {
        szam = "10";
    }
    
    var index = 1;
    var laptipus ="";
    if (szam == 10)
    {
        var index = 2;
    }
    if (lap[index] == 'D') {
        laptipus = "diamonds";
    } else if (lap[index] == 'H') {
        laptipus = "hearts";
    }else if (lap[index] == 'S') {
        laptipus = "spades";
    }else if (lap[index] == 'C') {
        laptipus ="clubs";
    }
    var filename = `card-img/${szam}_of_${laptipus}${version}.png`;
    console.log(filename);
    var img = document.createElement("img");
    img.src=filename;
    console.log(img);
    var src = document.getElementById(szereplo);
    src.appendChild(img);
}



